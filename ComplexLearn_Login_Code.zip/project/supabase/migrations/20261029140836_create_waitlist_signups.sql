/*
# Create waitlist signups table

1. New Tables
- `waitlist_signups`
  - `id` (uuid, primary key)
  - `email` (text, unique, not null) - the address a visitor submits to join the waitlist
  - `plan_interest` (text, not null) - either 'free' or 'premium', the plan the visitor clicked
  - `created_at` (timestamptz) - when the signup was recorded

2. Security
- Enable RLS on `waitlist_signups`.
- Grant INSERT only to `anon` and `authenticated`. Visitors can join the list but cannot read, edit, or delete any signups, so other visitors' email addresses stay private.
- One INSERT policy allows anonymous and signed-in visitors to add a row.
- No SELECT, UPDATE, or DELETE access is granted to any browser role.

3. Important Notes
- The unique constraint on `email` prevents duplicate signups; the website treats a duplicate as a successful join.
- The plan check limits `plan_interest` to the two plans the website offers.
*/

CREATE TABLE IF NOT EXISTS waitlist_signups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE CHECK (char_length(email) BETWEEN 3 AND 254),
  plan_interest text NOT NULL DEFAULT 'free' CHECK (plan_interest IN ('free', 'premium')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE waitlist_signups ENABLE ROW LEVEL SECURITY;

GRANT INSERT ON waitlist_signups TO anon, authenticated;

DROP POLICY IF EXISTS "anon_insert_waitlist_signups" ON waitlist_signups;
CREATE POLICY "anon_insert_waitlist_signups" ON waitlist_signups
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);
