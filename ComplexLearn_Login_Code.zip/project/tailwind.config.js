/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
      },
      colors: {
        ink: {
          50: '#f5f8fb',
          100: '#e9eef5',
          200: '#d6deea',
          300: '#b4c1d6',
          400: '#8a9bb8',
          500: '#5c7194',
          600: '#3a5275',
          700: '#22395f',
          800: '#17294a',
          900: '#0f1f38',
          950: '#0a1628',
        },
        brand: {
          50: '#ecfdf8',
          100: '#d1faee',
          200: '#a6f3de',
          300: '#6ee7c9',
          400: '#34d3ae',
          500: '#14b894',
          600: '#0d967a',
          700: '#0f7865',
          800: '#105f51',
          900: '#114e44',
        },
        gold: {
          100: '#fef3c7',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
        },
      },
    },
  },
  plugins: [],
};
