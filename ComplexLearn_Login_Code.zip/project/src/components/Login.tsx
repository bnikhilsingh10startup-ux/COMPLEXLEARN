import { useState } from 'react';
import { ArrowRight, BookOpen, BrainCircuit, CheckSquare, Eye, EyeOff, GraduationCap, LockKeyhole, Mail, Sparkles, Trophy, UserRound, Users } from 'lucide-react';
import './Login.css';

type LoginProps = { onSignUp: () => void };

export default function Login({ onSignUp }: LoginProps) {
  const [role, setRole] = useState<'student' | 'parent'>('student');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');

  function handleLogin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!userId.trim() || !password.trim()) {
      alert('Please enter your User ID and password.');
      return;
    }
    alert('This is a front-end demo. Connect a secure authentication service to enable real login.');
  }

  return (
    <div className="cl-login-page">
      <section className="cl-promo">
        <div className="cl-brand">
          <div className="cl-brand-mark"><BookOpen size={34} /><GraduationCap size={25} /></div>
          <div><strong>Complex <span>Learn</span></strong><small>LEARN • PRACTICE • ACHIEVE</small></div>
        </div>
        <div className="cl-promo-copy">
          <p className="cl-eyebrow"><Sparkles size={15} /> YOUR LEARNING PARTNER</p>
          <h1>Your Learning Partner for a <em>Brighter Future</em></h1>
          <p className="cl-promo-sub">Build confidence, discover your potential, and make every day a step forward.</p>
          <div className="cl-benefits">
            <div><span><BrainCircuit /></span>AI Doubt Solver</div>
            <div><span><CheckSquare /></span>Smart Mock Tests</div>
            <div><span><BookOpen /></span>Digital Library</div>
            <div><span><Trophy /></span>Earn Rewards</div>
          </div>
        </div>
        <div className="cl-student-art" aria-hidden="true">
          <div className="cl-orbit orbit-one" /><div className="cl-orbit orbit-two" />
          <div className="cl-lightbulb">✦</div>
          <div className="cl-student">🧑🏻‍🎓</div>
          <div className="cl-books"><b>MATH</b><b>SCIENCE</b><b>ENGLISH</b></div>
          <div className="cl-laptop"><span>✦</span><strong>Complex<br/>Learn</strong></div>
        </div>
        <div className="cl-promo-footer">Learn something new. Become something great.</div>
      </section>

      <section className="cl-form-side">
        <div className="cl-country"><span>🇮🇳</span> India <span className="cl-chevron">⌄</span></div>
        <div className="cl-login-card">
          <div className="cl-mobile-brand">Complex <span>Learn</span></div>
          <div className="cl-form-heading"><div className="cl-heading-icon"><GraduationCap /></div><h2>Welcome Back!</h2><p>Login to continue your learning journey</p></div>
          <div className="cl-role-tabs" role="tablist" aria-label="Login type">
            <button className={role === 'student' ? 'active' : ''} onClick={() => setRole('student')} type="button"><GraduationCap size={19}/> Student Login</button>
            <button className={role === 'parent' ? 'active' : ''} onClick={() => setRole('parent')} type="button"><Users size={19}/> Parent Login</button>
          </div>
          <form onSubmit={handleLogin}>
            <label className="cl-input-wrap"><UserRound size={19}/><input value={userId} onChange={e => setUserId(e.target.value)} placeholder={role === 'student' ? 'Student User ID' : 'Parent User ID'} autoComplete="username" /></label>
            <label className="cl-input-wrap"><LockKeyhole size={19}/><input value={password} onChange={e => setPassword(e.target.value)} type={showPassword ? 'text' : 'password'} placeholder="Password" autoComplete="current-password"/><button className="cl-eye" type="button" onClick={() => setShowPassword(!showPassword)} aria-label="Show or hide password">{showPassword ? <EyeOff size={19}/> : <Eye size={19}/>}</button></label>
            <div className="cl-form-options"><label className="cl-remember"><input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)}/> Remember Me</label><button type="button" className="cl-text-button" onClick={() => alert('Please contact your school or administrator to reset your password.')}>Forgot Password?</button></div>
            <button className="cl-submit" type="submit">Login <span><ArrowRight size={20}/></span></button>
          </form>
          <div className="cl-divider"><span/>or continue with<span/></div>
          <div className="cl-socials"><button type="button" onClick={() => alert('Google sign-in will be available after authentication is configured.')}><b className="google-g">G</b> Google</button><button type="button" onClick={() => alert('Microsoft sign-in will be available after authentication is configured.')}><span className="ms-logo"><i/><i/><i/><i/></span> Microsoft</button></div>
          <p className="cl-signup">Don’t have an account? <button onClick={onSignUp} type="button">Sign Up <ArrowRight size={17}/></button></p>
          <p className="cl-safe-note"><LockKeyhole size={13}/> Your learning account should always stay secure.</p>
        </div>
      </section>
    </div>
  );
}
