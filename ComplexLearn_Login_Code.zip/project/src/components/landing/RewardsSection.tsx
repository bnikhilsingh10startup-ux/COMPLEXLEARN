import { Coins, Gift, Medal, Target, BookOpen, Star } from 'lucide-react';
import Reveal from '@/components/Reveal';
import SectionHeading from '@/components/landing/SectionHeading';

const EARN_WAYS = [
  { icon: Target, text: 'Completing tests' },
  { icon: Medal, text: 'Achieving good scores' },
  { icon: Star, text: 'Improving performance over time' },
  { icon: BookOpen, text: 'Other qualifying educational activities' },
];

const PRIZES = ['School bags', 'Pens', 'Stationery', 'Educational books', 'School supply kits'];

export default function RewardsSection() {
  return (
    <section id="rewards" className="bg-ink-950 py-24 text-white sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal>
          <SectionHeading
            tone="dark"
            eyebrow="Coins and rewards"
            title="Coins and rewards encourage regular learning"
            description="Students may earn coins by completing tests, achieving good scores, improving their performance, and completing other qualifying educational activities."
          />
        </Reveal>

        <div className="mt-16 grid gap-6 lg:grid-cols-5">
          <Reveal className="lg:col-span-2">
            <div className="h-full rounded-3xl border border-ink-700 bg-ink-900 p-8">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-gold-400/15 text-gold-300">
                <Coins className="h-6 w-6" aria-hidden="true" />
              </span>
              <h3 className="mt-6 text-xl font-bold">Ways to earn coins</h3>
              <ul className="mt-6 space-y-4">
                {EARN_WAYS.map((way) => (
                  <li key={way.text} className="flex items-center gap-3 text-base text-ink-100">
                    <way.icon className="h-5 w-5 shrink-0 text-brand-300" aria-hidden="true" />
                    {way.text}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <Reveal delay={150} className="lg:col-span-3">
            <div className="h-full rounded-3xl border border-ink-700 bg-gradient-to-br from-ink-900 to-ink-800 p-8 sm:p-10">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-500/15 text-brand-300">
                <Gift className="h-6 w-6" aria-hidden="true" />
              </span>
              <h3 className="mt-6 text-xl font-bold">Possible prizes</h3>
              <ul className="mt-6 flex flex-wrap gap-3">
                {PRIZES.map((prize) => (
                  <li
                    key={prize}
                    className="rounded-full border border-ink-600 bg-ink-950/60 px-4 py-2 text-sm font-semibold text-ink-100 transition-colors duration-200 hover:border-gold-400 hover:text-gold-300"
                  >
                    {prize}
                  </li>
                ))}
              </ul>
              <p className="mt-10 border-t border-ink-700 pt-8 text-base text-ink-200">
                The rewards system is designed to encourage genuine learning rather than unhealthy competition.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
