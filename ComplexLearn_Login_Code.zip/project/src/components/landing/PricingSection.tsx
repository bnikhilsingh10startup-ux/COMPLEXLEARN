import { Check, Minus } from 'lucide-react';
import Reveal from '@/components/Reveal';
import SectionHeading from '@/components/landing/SectionHeading';
import type { Plan } from '@/lib/plans';

interface PricingSectionProps {
  onChoosePlan: (plan: Plan) => void;
}

interface Feature {
  label: string;
  free: string | false;
  premium: string | false;
}

const FEATURES: Feature[] = [
  { label: 'AI doubt questions', free: 'Limited', premium: 'Unlimited' },
  { label: 'Smart tests', free: 'Limited', premium: 'Unlimited' },
  { label: 'Digital Library reading', free: false, premium: 'Unlimited' },
  { label: 'Educational Newspaper reading', free: 'Once a week', premium: 'Unlimited' },
  { label: 'Coins and rewards', free: 'Included', premium: 'Included' },
];

function FeatureValue({ value }: { value: string | false }) {
  if (value === false) {
    return (
      <span className="inline-flex items-center gap-2 text-ink-400">
        <Minus className="h-4 w-4" aria-hidden="true" />
        Not included
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-2 font-semibold text-ink-800">
      <Check className="h-4 w-4 text-brand-600" aria-hidden="true" />
      {value}
    </span>
  );
}

export default function PricingSection({ onChoosePlan }: PricingSectionProps) {
  return (
    <section id="pricing" className="bg-ink-50 py-24 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal>
          <SectionHeading
            align="center"
            eyebrow="Pricing"
            title="Free access creates reach; Premium supports the business"
            description="Start for free and upgrade when you want unlimited practice and reading."
          />
        </Reveal>

        <div className="mt-16 grid gap-6 lg:grid-cols-2 lg:gap-8">
          <Reveal>
            <div className="flex h-full flex-col rounded-3xl border border-ink-200 bg-white p-8 sm:p-10">
              <p className="text-sm font-bold uppercase tracking-widest text-ink-500">Free plan</p>
              <p className="mt-4 text-4xl font-bold text-ink-900">
                ₹0<span className="text-base font-semibold text-ink-500"> / month</span>
              </p>
              <p className="mt-4 text-base text-ink-600">Limited AI questions, limited tests, and newspaper reading once a week.</p>
              <button
                type="button"
                onClick={() => onChoosePlan('free')}
                className="mt-8 rounded-full border border-ink-300 px-6 py-3 text-base font-bold text-ink-900 transition-colors duration-200 hover:border-brand-500 hover:bg-brand-50"
              >
                Join with the Free plan
              </button>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="relative flex h-full flex-col rounded-3xl bg-ink-950 p-8 text-white shadow-2xl shadow-ink-900/25 sm:p-10">
              <span className="absolute -top-3 right-8 rounded-full bg-gold-400 px-3 py-1 text-xs font-bold uppercase tracking-wide text-ink-950">
                Most complete
              </span>
              <p className="text-sm font-bold uppercase tracking-widest text-brand-300">Premium plan</p>
              <p className="mt-4 text-4xl font-bold">
                ₹89<span className="text-base font-semibold text-ink-300"> / month</span>
              </p>
              <p className="mt-4 text-base text-ink-200">
                Unlimited AI questions, unlimited tests, unlimited Digital Library reading, and unlimited newspaper
                reading.
              </p>
              <button
                type="button"
                onClick={() => onChoosePlan('premium')}
                className="mt-8 rounded-full bg-brand-500 px-6 py-3 text-base font-bold text-ink-950 transition-all duration-200 hover:-translate-y-0.5 hover:bg-brand-400 hover:shadow-lg hover:shadow-brand-500/30"
              >
                Join with Premium
              </button>
            </div>
          </Reveal>
        </div>

        <Reveal className="mt-10">
          <div className="overflow-x-auto rounded-3xl border border-ink-200 bg-white">
            <table className="w-full min-w-[480px] text-left text-sm sm:text-base">
              <thead>
                <tr className="border-b border-ink-100 bg-ink-50 text-ink-600">
                  <th scope="col" className="px-6 py-4 font-semibold">Feature</th>
                  <th scope="col" className="px-6 py-4 font-semibold">Free</th>
                  <th scope="col" className="px-6 py-4 font-semibold">Premium</th>
                </tr>
              </thead>
              <tbody>
                {FEATURES.map((feature) => (
                  <tr key={feature.label} className="border-b border-ink-100 last:border-0">
                    <th scope="row" className="px-6 py-4 font-medium text-ink-800">{feature.label}</th>
                    <td className="px-6 py-4"><FeatureValue value={feature.free} /></td>
                    <td className="px-6 py-4"><FeatureValue value={feature.premium} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-6 text-sm text-ink-500">
            Premium is subject to reasonable technical safeguards and applicable service terms. Free and Premium
            students may both take part in the coins and rewards system under the same eligibility rules.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
