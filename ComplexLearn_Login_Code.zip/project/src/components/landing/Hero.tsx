import { ArrowRight, Brain, ClipboardCheck, Trophy } from 'lucide-react';

export default function Hero() {
  return (
    <section
      id="top"
      className="relative overflow-hidden bg-ink-950 pt-28 text-white sm:pt-32 lg:min-h-screen lg:pt-0"
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-70"
        style={{
          background:
            'radial-gradient(60% 50% at 80% 20%, rgba(20,184,148,0.25), transparent 70%), radial-gradient(40% 40% at 10% 90%, rgba(52,211,174,0.12), transparent 70%)',
        }}
      />

      <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-5 pb-20 sm:px-8 lg:min-h-screen lg:grid-cols-2 lg:gap-16 lg:pb-0">
        <div>
          <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand-400/30 bg-brand-500/10 px-4 py-1.5 text-sm font-semibold text-brand-200">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-400" />
            Learning support beyond the classroom
          </p>

          <h1 className="text-5xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl">
            Complex
            <span className="block text-brand-300">Learn</span>
          </h1>

          <p className="mt-6 max-w-xl text-xl font-semibold text-ink-100 sm:text-2xl">
            An all-in-one learning platform for every student
          </p>

          <div className="mt-6 h-px w-40 bg-gradient-to-r from-transparent via-brand-400 to-transparent" />

          <p className="mt-6 max-w-xl text-lg text-ink-200">
            One platform. Every student. Better learning.
          </p>

          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <a
              href="#waitlist"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-brand-500 px-7 py-3.5 text-base font-bold text-ink-950 transition-all duration-200 hover:-translate-y-0.5 hover:bg-brand-400 hover:shadow-xl hover:shadow-brand-500/30"
            >
              Join the waitlist
              <ArrowRight className="h-5 w-5 transition-transform duration-200 group-hover:translate-x-1" />
            </a>
            <a
              href="#features"
              className="inline-flex items-center justify-center rounded-full border border-ink-500 px-7 py-3.5 text-base font-semibold text-white transition-colors duration-200 hover:border-brand-300 hover:text-brand-200"
            >
              Explore the features
            </a>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-lg lg:max-w-none">
          <div className="overflow-hidden rounded-3xl border border-white/10 shadow-2xl shadow-black/40">
            <img
              src="https://images.pexels.com/photos/6549355/pexels-photo-6549355.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
              alt="A student studying at a desk under a warm lamp at night"
              className="h-full w-full object-cover"
              loading="eager"
            />
          </div>

          <div className="animate-float-soft absolute -left-4 top-8 hidden rounded-2xl border border-ink-700 bg-ink-900/95 p-4 shadow-xl sm:block">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/20 text-brand-300">
                <Brain className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-semibold text-white">Doubt solved</p>
                <p className="text-xs text-ink-300">Explained step by step</p>
              </div>
            </div>
          </div>

          <div
            className="animate-float-soft absolute -right-4 bottom-10 hidden rounded-2xl border border-ink-700 bg-ink-900/95 p-4 shadow-xl sm:block"
            style={{ animationDelay: '1.5s' }}
          >
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold-400/20 text-gold-300">
                <Trophy className="h-5 w-5" aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-semibold text-white">Coins earned</p>
                <p className="text-xs text-ink-300">For completed tests</p>
              </div>
            </div>
          </div>

          <div
            className="animate-float-soft absolute -bottom-6 left-10 hidden items-center gap-3 rounded-2xl border border-ink-700 bg-ink-900/95 p-4 shadow-xl md:flex"
            style={{ animationDelay: '3s' }}
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/20 text-brand-300">
              <ClipboardCheck className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <p className="text-sm font-semibold text-white">Chapter test</p>
              <p className="text-xs text-ink-300">Score: 86 percent</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
