import { CheckCircle2 } from 'lucide-react';
import Reveal from '@/components/Reveal';
import SectionHeading from '@/components/landing/SectionHeading';

const STEPS = [
  'Identify the questions and answers on each scanned answer sheet.',
  'Compare each response with the answer key or marking scheme.',
  'Suggest marks for every answer.',
  'The teacher reviews the suggested marks and confirms the final result.',
];

export default function EvaluationSection() {
  return (
    <section id="evaluation" className="bg-ink-50 py-24 sm:py-28">
      <div className="mx-auto grid max-w-6xl items-center gap-16 px-5 sm:px-8 lg:grid-cols-2">
        <Reveal>
          <div>
            <SectionHeading
              eyebrow="Question Paper Scanner and Evaluator"
              title="AI-assisted evaluation supports teachers"
              description="The Question Paper Scanner and Evaluator is designed to help teachers evaluate students' answer sheets more efficiently. Teachers stay in control of every mark."
            />
          </div>
        </Reveal>

        <Reveal delay={150}>
          <ol className="space-y-4">
            {STEPS.map((step, index) => (
              <li
                key={step}
                className="flex items-start gap-5 rounded-2xl border border-ink-100 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-ink-900/5"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink-900 text-sm font-bold text-brand-300">
                  {index + 1}
                </span>
                <div className="flex-1">
                  <p className="text-base text-ink-800">{step}</p>
                </div>
                {index === STEPS.length - 1 && (
                  <CheckCircle2 className="mt-1 h-5 w-5 shrink-0 text-brand-600" aria-hidden="true" />
                )}
              </li>
            ))}
          </ol>
        </Reveal>
      </div>
    </section>
  );
}
