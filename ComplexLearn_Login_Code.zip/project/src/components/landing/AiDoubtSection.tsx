import { MessageSquareText, ListOrdered, CheckCheck } from 'lucide-react';
import Reveal from '@/components/Reveal';

const EXAMPLE_STEPS = [
  'Write the two fractions with the same denominator: 2/3 = 4/6.',
  'Add the numerators: 4/6 + 1/6 = 5/6.',
  'The answer is 5/6, because the parts are counted in sixths.',
];

export default function AiDoubtSection() {
  return (
    <section id="doubt-solver" className="bg-ink-950 py-24 text-white sm:py-28">
      <div className="mx-auto grid max-w-6xl items-center gap-16 px-5 sm:px-8 lg:grid-cols-2">
        <Reveal>
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-brand-300">AI Doubt Solver</p>
            <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
              Explains how and why
            </h2>
            <p className="mt-6 text-lg text-ink-200">
              Students can ask questions and receive explanations in simple language across Mathematics, Science,
              Social Studies, English, and other subjects.
            </p>
            <p className="mt-4 text-lg text-ink-200">
              The purpose is not simply to provide answers, but to help students understand how and why an answer
              is correct, with examples, summaries, and follow-up explanations.
            </p>

            <div className="mt-10 grid gap-3 sm:grid-cols-3">
              {['Mathematics', 'Science', 'Social Studies', 'English', 'And more'].map((subject) => (
                <span
                  key={subject}
                  className="rounded-full border border-ink-700 bg-ink-900 px-4 py-2 text-center text-sm font-semibold text-ink-100"
                >
                  {subject}
                </span>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={150}>
          <div className="rounded-3xl border border-ink-700 bg-ink-900 p-6 shadow-2xl shadow-black/40 sm:p-8">
            <div className="flex items-center gap-3 border-b border-ink-700 pb-5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/15 text-brand-300">
                <MessageSquareText className="h-5 w-5" aria-hidden="true" />
              </span>
              <p className="text-sm font-semibold text-ink-200">Example conversation</p>
            </div>

            <div className="mt-6 space-y-6">
              <div className="ml-auto max-w-[85%] rounded-2xl rounded-br-md bg-brand-500 px-5 py-4 text-ink-950">
                <p className="text-sm font-semibold">Student</p>
                <p className="mt-1 text-base">Why is 2/3 + 1/6 equal to 5/6?</p>
              </div>

              <div className="max-w-[92%] rounded-2xl rounded-bl-md border border-ink-700 bg-ink-800 px-5 py-4">
                <p className="text-sm font-semibold text-brand-300">Complex Learn</p>
                <ol className="mt-3 space-y-3">
                  {EXAMPLE_STEPS.map((step, index) => (
                    <li key={step} className="flex gap-3 text-base text-ink-100">
                      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-500/20 text-xs font-bold text-brand-300">
                        {index + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
                <div className="mt-5 flex items-center gap-2 text-sm text-ink-300">
                  <CheckCheck className="h-4 w-4 text-brand-300" aria-hidden="true" />
                  <span>Follow-up explanations for related questions</span>
                </div>
              </div>
            </div>

            <p className="mt-6 flex items-center gap-2 text-xs text-ink-400">
              <ListOrdered className="h-4 w-4" aria-hidden="true" />
              Illustrative example of the explanation style
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
