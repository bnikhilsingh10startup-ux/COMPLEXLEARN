import { GraduationCap } from 'lucide-react';

const FOOTER_LINKS = [
  { href: '#features', label: 'Features' },
  { href: '#resources', label: 'Resources' },
  { href: '#rewards', label: 'Rewards' },
  { href: '#pricing', label: 'Pricing' },
];

export default function Footer() {
  return (
    <footer className="border-t border-ink-900 bg-ink-950 text-ink-300">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-5 py-12 sm:px-8 md:flex-row md:items-center md:justify-between">
        <div>
          <a href="#top" className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-500 text-ink-950">
              <GraduationCap className="h-5 w-5" aria-hidden="true" />
            </span>
            <span className="text-lg font-bold text-white">Complex Learn</span>
          </a>
          <p className="mt-3 text-sm">One platform. Every student. Better learning.</p>
        </div>

        <nav aria-label="Footer" className="flex flex-wrap gap-x-8 gap-y-3">
          {FOOTER_LINKS.map((link) => (
            <a key={link.href} href={link.href} className="text-sm font-semibold transition-colors duration-200 hover:text-brand-300">
              {link.label}
            </a>
          ))}
        </nav>
      </div>

      <div className="border-t border-ink-900">
        <p className="mx-auto max-w-6xl px-5 py-6 text-xs text-ink-400 sm:px-8">
          &copy; {new Date().getFullYear()} Complex Learn. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
