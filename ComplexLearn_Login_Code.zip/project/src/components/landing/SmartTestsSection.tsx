import { BarChart3 } from 'lucide-react';
import Reveal from '@/components/Reveal';
import SectionHeading from '@/components/landing/SectionHeading';

const TEST_TYPES = [
  { step: '01', title: 'Chapter-wise tests', description: 'Practise one chapter at a time as you finish it.' },
  { step: '02', title: 'Subject-wise tests', description: 'Cover everything you have studied in a full subject.' },
  { step: '03', title: 'Revision tests', description: 'Refresh earlier lessons before an exam.' },
  { step: '04', title: 'Mock examinations', description: 'Sit a full-length practice paper under exam conditions.' },
];

const SAMPLE_TOPICS = [
  { topic: 'Algebra', score: 86 },
  { topic: 'Geometry', score: 58 },
  { topic: 'Trigonometry', score: 72 },
  { topic: 'Statistics', score: 41 },
];

export default function SmartTestsSection() {
  return (
    <section id="tests" className="bg-white py-24 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="Smart Test System"
            title="Turn practice into progress"
            description="Students can select a subject, choose a chapter, take a test, and receive their scores."
          />
        </Reveal>

        <div className="mt-16 grid gap-10 lg:grid-cols-5">
          <div className="grid gap-5 sm:grid-cols-2 lg:col-span-3">
            {TEST_TYPES.map((test, index) => (
              <Reveal key={test.step} delay={index * 80}>
                <div className="group h-full rounded-2xl border border-ink-100 bg-ink-50/60 p-7 transition-all duration-300 hover:-translate-y-1 hover:border-brand-200 hover:bg-white hover:shadow-xl hover:shadow-ink-900/5">
                  <p className="text-sm font-bold text-brand-600">{test.step}</p>
                  <div className="mt-3 h-0.5 w-full rounded-full bg-brand-500" />
                  <h3 className="mt-6 text-xl font-bold text-ink-900">{test.title}</h3>
                  <p className="mt-2 text-base text-ink-600">{test.description}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={200} className="lg:col-span-2">
            <div className="h-full rounded-3xl bg-ink-950 p-8 text-white shadow-xl shadow-ink-900/20">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/20 text-brand-300">
                  <BarChart3 className="h-5 w-5" aria-hidden="true" />
                </span>
                <p className="font-semibold">Sample results</p>
              </div>

              <div className="mt-8 space-y-6">
                {SAMPLE_TOPICS.map((item, index) => (
                  <div key={item.topic}>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-ink-100">{item.topic}</span>
                      <span className={item.score < 60 ? 'font-bold text-gold-300' : 'font-bold text-brand-300'}>
                        {item.score}%
                      </span>
                    </div>
                    <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-ink-800">
                      <div
                        className={`bar-grow h-full rounded-full ${
                          item.score < 60 ? 'bg-gold-400' : 'bg-brand-400'
                        }`}
                        style={{ width: `${item.score}%`, animationDelay: `${index * 120}ms` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <p className="mt-8 rounded-xl border border-gold-400/30 bg-gold-400/10 p-4 text-sm text-ink-100">
                Results help students identify topics that require more attention. Geometry and Statistics need
                revision.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
