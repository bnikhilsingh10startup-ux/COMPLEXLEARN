import { useEffect, useState } from 'react';
import { GraduationCap, Menu, X } from 'lucide-react';

const NAV_LINKS = [
  { href: '#features', label: 'Features' },
  { href: '#audience', label: 'Who it is for' },
  { href: '#resources', label: 'Resources' },
  { href: '#pricing', label: 'Pricing' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled || menuOpen
          ? 'bg-white/95 shadow-sm shadow-ink-900/5 backdrop-blur-md'
          : 'bg-transparent'
      }`}
    >
      <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
        <a href="#top" className="flex items-center gap-2" onClick={closeMenu}>
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-500 text-ink-950">
            <GraduationCap className="h-5 w-5" aria-hidden="true" />
          </span>
          <span
            className={`text-lg font-bold transition-colors duration-300 ${
              scrolled || menuOpen ? 'text-ink-900' : 'text-white'
            }`}
          >
            Complex Learn
          </span>
        </a>

        <div className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`text-sm font-semibold transition-colors duration-200 hover:text-brand-500 ${
                scrolled ? 'text-ink-700' : 'text-ink-100'
              }`}
            >
              {link.label}
            </a>
          ))}
          <a
            href="#waitlist"
            className="rounded-full bg-brand-500 px-5 py-2.5 text-sm font-bold text-ink-950 transition-all duration-200 hover:-translate-y-0.5 hover:bg-brand-400 hover:shadow-lg hover:shadow-brand-500/30"
          >
            Join the waitlist
          </a>
        </div>

        <button
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          className={`flex h-10 w-10 items-center justify-center rounded-lg md:hidden ${
            scrolled || menuOpen ? 'text-ink-900' : 'text-white'
          }`}
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
        >
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {menuOpen && (
        <div className="border-t border-ink-100 bg-white px-5 pb-6 pt-2 md:hidden">
          <div className="flex flex-col">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={closeMenu}
                className="border-b border-ink-100 py-3.5 text-base font-semibold text-ink-800"
              >
                {link.label}
              </a>
            ))}
          </div>
          <a
            href="#waitlist"
            onClick={closeMenu}
            className="mt-5 block rounded-full bg-brand-500 px-5 py-3 text-center text-sm font-bold text-ink-950"
          >
            Join the waitlist
          </a>
        </div>
      )}
    </header>
  );
}
