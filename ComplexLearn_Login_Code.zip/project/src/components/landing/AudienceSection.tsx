import { GraduationCap, Presentation, School, Heart, BookMarked, type LucideIcon } from 'lucide-react';
import Reveal from '@/components/Reveal';
import SectionHeading from '@/components/landing/SectionHeading';

interface Audience {
  icon: LucideIcon;
  text: string;
}

const AUDIENCE: Audience[] = [
  { icon: GraduationCap, text: 'Students who struggle with particular subjects' },
  { icon: BookMarked, text: 'Students who want to revise lessons regularly' },
  { icon: School, text: 'Students preparing for school examinations' },
  { icon: Presentation, text: 'Teachers who want assistance with evaluating answer sheets' },
  { icon: Heart, text: "Parents who want to support their children's education" },
];

export default function AudienceSection() {
  return (
    <section id="audience" className="bg-white py-24 sm:py-28">
      <div className="mx-auto grid max-w-6xl gap-16 px-5 sm:px-8 lg:grid-cols-2 lg:items-center">
        <Reveal>
          <div>
            <SectionHeading
              eyebrow="Who it is for"
              title="Built for students, with support for teachers and parents"
            />
            <div className="mt-10 overflow-hidden rounded-3xl">
              <img
                src="https://images.pexels.com/photos/8617888/pexels-photo-8617888.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="A teacher and a group of students learning together with books"
                className="aspect-[16/10] w-full object-cover"
                loading="lazy"
              />
            </div>
          </div>
        </Reveal>

        <ul className="divide-y divide-ink-100 rounded-3xl border border-ink-100 bg-ink-50/60 px-6 sm:px-8">
          {AUDIENCE.map((item, index) => (
            <li key={item.text}>
              <Reveal delay={index * 90}>
                <div className="group flex items-center gap-5 py-6">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white text-brand-600 shadow-sm ring-1 ring-ink-100 transition-all duration-300 group-hover:bg-brand-500 group-hover:text-ink-950">
                    <item.icon className="h-6 w-6" aria-hidden="true" />
                  </span>
                  <span className="text-lg font-semibold text-ink-800">{item.text}</span>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
