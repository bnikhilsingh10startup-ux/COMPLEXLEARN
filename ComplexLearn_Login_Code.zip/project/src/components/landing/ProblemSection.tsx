import { MessageCircleQuestion, UserRound, Wallet } from 'lucide-react';
import Reveal from '@/components/Reveal';

const CHALLENGES = [
  {
    icon: MessageCircleQuestion,
    text: 'Subjects that feel difficult to understand, with no one nearby to explain them.',
  },
  {
    icon: UserRound,
    text: 'No easy access to a personal tutor or immediate answers to doubts.',
  },
  {
    icon: Wallet,
    text: 'Limited access to extra study materials beyond the textbook.',
  },
];

export default function ProblemSection() {
  return (
    <section className="bg-white py-24 sm:py-28">
      <div className="mx-auto grid max-w-6xl items-center gap-16 px-5 sm:px-8 lg:grid-cols-2">
        <Reveal>
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-brand-600">The problem</p>
            <h2 className="mt-4 text-3xl font-bold tracking-tight text-ink-900 sm:text-4xl lg:text-5xl">
              Students need learning support beyond the classroom
            </h2>
            <p className="mt-6 text-lg text-ink-600">
              Many students find certain subjects difficult to understand. They may not always have access to
              personal tutors, additional study materials, or immediate answers to their doubts.
            </p>
            <p className="mt-4 text-lg text-ink-600">
              These challenges can affect confidence, academic performance, and interest in learning.
            </p>

            <ul className="mt-10 space-y-5">
              {CHALLENGES.map((challenge) => (
                <li key={challenge.text} className="flex items-start gap-4">
                  <span className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-ink-100 text-ink-700">
                    <challenge.icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <span className="pt-2 text-base text-ink-700">{challenge.text}</span>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <Reveal delay={150}>
          <div className="relative">
            <div className="overflow-hidden rounded-3xl shadow-2xl shadow-ink-900/15">
              <img
                src="https://images.pexels.com/photos/36543210/pexels-photo-36543210.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="A student focused on an open book during a late-night study session"
                className="aspect-[4/3] h-full w-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 hidden rounded-2xl bg-ink-950 px-6 py-5 text-white shadow-xl sm:block">
              <p className="text-3xl font-bold text-brand-300">One place</p>
              <p className="mt-1 text-sm text-ink-200">for doubts, tests and study materials</p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
