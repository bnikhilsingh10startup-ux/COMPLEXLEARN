import { Landmark, Newspaper, type LucideIcon } from 'lucide-react';
import Reveal from '@/components/Reveal';
import SectionHeading from '@/components/landing/SectionHeading';

interface ResourceCard {
  icon: LucideIcon;
  title: string;
  description: string;
  items: string[];
}

const RESOURCES: ResourceCard[] = [
  {
    icon: Landmark,
    title: 'Digital Library',
    description:
      'The Digital Library may contain subject notes, chapter summaries, revision materials, educational reference documents, and other useful learning resources.',
    items: ['Subject notes', 'Chapter summaries', 'Revision materials', 'Reference documents'],
  },
  {
    icon: Newspaper,
    title: 'Educational Newspaper',
    description:
      'The Educational Newspaper section may cover Indian current affairs, government initiatives, science and technology, education, environmental issues, and other educational topics.',
    items: ['Indian current affairs', 'Government initiatives', 'Science and technology', 'Environment'],
  },
];

export default function ResourcesSection() {
  return (
    <section id="resources" className="bg-white py-24 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="Learning resources"
            title="Learning resources stay in one place"
          />
        </Reveal>

        <div className="mt-16 grid gap-8 lg:grid-cols-2">
          {RESOURCES.map((resource, index) => (
            <Reveal key={resource.title} delay={index * 120}>
              <article className="group flex h-full flex-col rounded-3xl border border-ink-100 bg-gradient-to-br from-ink-50 to-brand-50/60 p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-ink-900/5 sm:p-10">
                <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-ink-900 text-brand-300 transition-transform duration-300 group-hover:scale-105">
                  <resource.icon className="h-7 w-7" aria-hidden="true" />
                </span>
                <h3 className="mt-8 text-2xl font-bold text-ink-900">{resource.title}</h3>
                <p className="mt-4 text-base text-ink-600">{resource.description}</p>
                <ul className="mt-8 flex flex-wrap gap-2">
                  {resource.items.map((item) => (
                    <li
                      key={item}
                      className="rounded-full bg-white px-3.5 py-1.5 text-sm font-semibold text-ink-700 ring-1 ring-ink-200"
                    >
                      {item}
                    </li>
                  ))}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
