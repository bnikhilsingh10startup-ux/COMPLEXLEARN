import { useState, type FormEvent } from 'react';
import { ArrowRight, CheckCircle2, Loader2 } from 'lucide-react';
import Reveal from '@/components/Reveal';
import { PLAN_LABELS, type Plan } from '@/lib/plans';
import { supabase } from '@/lib/supabase';

interface WaitlistSectionProps {
  plan: Plan;
  onPlanChange: (plan: Plan) => void;
}

type SubmitStatus = 'idle' | 'submitting' | 'success' | 'error';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const UNIQUE_VIOLATION_CODE = '23505';

export default function WaitlistSection({ plan, onPlanChange }: WaitlistSectionProps) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<SubmitStatus>('idle');
  const [message, setMessage] = useState('');

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const normalizedEmail = email.trim().toLowerCase();

    if (!EMAIL_PATTERN.test(normalizedEmail) || normalizedEmail.length > 254) {
      setStatus('error');
      setMessage('Please enter a valid email address.');
      return;
    }

    setStatus('submitting');
    setMessage('');

    const { error } = await supabase
      .from('waitlist_signups')
      .insert({ email: normalizedEmail, plan_interest: plan });

    if (error && error.code !== UNIQUE_VIOLATION_CODE) {
      setStatus('error');
      setMessage('Something went wrong while saving your details. Please try again in a moment.');
      return;
    }

    setStatus('success');
    setEmail('');
  };

  const isSubmitting = status === 'submitting';

  return (
    <section id="waitlist" className="relative overflow-hidden bg-ink-950 py-24 text-white sm:py-28">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(50% 60% at 50% 0%, rgba(20,184,148,0.22), transparent 70%)',
        }}
      />

      <div className="relative mx-auto max-w-3xl px-5 text-center sm:px-8">
        <Reveal>
          <p className="text-sm font-bold uppercase tracking-widest text-brand-300">Get early access</p>
          <h2 className="mt-4 text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl">
            Be the first to learn with Complex Learn
          </h2>
          <p className="mt-5 text-lg text-ink-200">
            Join the waitlist and we will let you know when Complex Learn is ready for you.
          </p>
        </Reveal>

        <Reveal delay={120}>
          {status === 'success' ? (
            <div className="mt-12 rounded-3xl border border-brand-400/40 bg-brand-500/10 p-8" role="status">
              <CheckCircle2 className="mx-auto h-12 w-12 text-brand-300" aria-hidden="true" />
              <p className="mt-4 text-xl font-bold">You are on the list</p>
              <p className="mt-2 text-base text-ink-200">
                Thank you for joining for the {PLAN_LABELS[plan]} plan.
              </p>
              <button
                type="button"
                onClick={() => setStatus('idle')}
                className="mt-6 text-sm font-semibold text-brand-300 underline-offset-4 hover:underline"
              >
                Add another email
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="mt-12 space-y-6 text-left">
              <div role="radiogroup" aria-label="Plan" className="grid grid-cols-2 gap-3">
                {(Object.keys(PLAN_LABELS) as Plan[]).map((option) => {
                  const selected = plan === option;
                  return (
                    <button
                      key={option}
                      type="button"
                      role="radio"
                      aria-checked={selected}
                      onClick={() => onPlanChange(option)}
                      className={`rounded-2xl border px-5 py-4 text-left transition-all duration-200 ${
                        selected
                          ? 'border-brand-400 bg-brand-500/15 text-white'
                          : 'border-ink-700 bg-ink-900 text-ink-200 hover:border-ink-500'
                      }`}
                    >
                      <span className="block text-base font-bold">{PLAN_LABELS[option]} plan</span>
                      <span className="mt-1 block text-sm text-ink-300">
                        {option === 'free' ? 'Start learning at no cost' : 'Unlimited practice and reading'}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div>
                <label htmlFor="waitlist-email" className="block text-sm font-semibold text-ink-100">
                  Email address
                </label>
                <div className="mt-2 flex flex-col gap-3 sm:flex-row">
                  <input
                    id="waitlist-email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(event) => {
                      setEmail(event.target.value);
                      if (status === 'error') setStatus('idle');
                    }}
                    disabled={isSubmitting}
                    className="w-full rounded-full border border-ink-600 bg-ink-900 px-6 py-3.5 text-base text-white placeholder:text-ink-400 transition-colors duration-200 focus:border-brand-400 focus:outline-none focus:ring-2 focus:ring-brand-400/40 disabled:opacity-60"
                  />
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="group inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-brand-500 px-7 py-3.5 text-base font-bold text-ink-950 transition-all duration-200 hover:bg-brand-400 hover:shadow-lg hover:shadow-brand-500/30 disabled:cursor-not-allowed disabled:opacity-70"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
                        Joining
                      </>
                    ) : (
                      <>
                        Join the waitlist
                        <ArrowRight className="h-5 w-5 transition-transform duration-200 group-hover:translate-x-1" aria-hidden="true" />
                      </>
                    )}
                  </button>
                </div>
              </div>

              <p
                aria-live="polite"
                className={`min-h-6 text-center text-sm ${status === 'error' ? 'text-red-300' : 'text-ink-300'}`}
              >
                {status === 'error' ? message : 'We only use your email to contact you about Complex Learn.'}
              </p>
            </form>
          )}
        </Reveal>
      </div>
    </section>
  );
}
