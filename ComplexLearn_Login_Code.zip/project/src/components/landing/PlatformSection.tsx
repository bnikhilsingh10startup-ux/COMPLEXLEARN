import { Brain, BookOpen, ClipboardList, Library, Trophy, ScanLine, type LucideIcon } from 'lucide-react';
import Reveal from '@/components/Reveal';
import SectionHeading from '@/components/landing/SectionHeading';

interface Pillar {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
}

const PILLARS: Pillar[] = [
  {
    icon: Brain,
    title: 'AI Doubt Solver',
    description: 'Ask any question and get a clear explanation in simple language.',
    href: '#doubt-solver',
  },
  {
    icon: ClipboardList,
    title: 'Smart Test System',
    description: 'Take chapter, subject, revision and mock tests, then see where to improve.',
    href: '#tests',
  },
  {
    icon: ScanLine,
    title: 'AI-assisted Evaluation',
    description: 'Teachers get suggested marks for answer sheets, reviewed before they are final.',
    href: '#evaluation',
  },
  {
    icon: Library,
    title: 'Learning Resources',
    description: 'Digital Library notes and an Educational Newspaper in one place.',
    href: '#resources',
  },
  {
    icon: Trophy,
    title: 'Coins and Rewards',
    description: 'Earn coins for genuine learning and redeem them for school supplies and books.',
    href: '#rewards',
  },
];

export default function PlatformSection() {
  return (
    <section id="features" className="bg-ink-50 py-24 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="The platform"
            title="Complex Learn brings essential learning tools together"
            description="Complex Learn is an all-in-one learning platform designed to help students understand difficult subjects, practise questions, improve their knowledge, and monitor academic progress."
          />
        </Reveal>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-6">
          {PILLARS.map((pillar, index) => (
            <Reveal
              key={pillar.title}
              delay={index * 80}
              className={index < 3 ? 'lg:col-span-2' : 'lg:col-span-3'}
            >
              <a
                href={pillar.href}
                className="group flex h-full flex-col rounded-2xl border border-ink-100 bg-white p-7 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-xl hover:shadow-ink-900/5"
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600 transition-colors duration-300 group-hover:bg-brand-500 group-hover:text-ink-950">
                  <pillar.icon className="h-6 w-6" aria-hidden="true" />
                </span>
                <h3 className="mt-6 text-xl font-bold text-ink-900">{pillar.title}</h3>
                <p className="mt-3 text-base text-ink-600">{pillar.description}</p>
                <span className="mt-auto inline-flex items-center gap-1 pt-6 text-sm font-semibold text-brand-700">
                  Learn more
                  <BookOpen className="h-4 w-4 opacity-0 transition-opacity duration-200 group-hover:opacity-100" aria-hidden="true" />
                </span>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
