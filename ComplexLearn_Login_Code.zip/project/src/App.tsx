import { useState } from 'react';
import Login from '@/components/Login';
import Navbar from '@/components/landing/Navbar';
import Hero from '@/components/landing/Hero';
import ProblemSection from '@/components/landing/ProblemSection';
import PlatformSection from '@/components/landing/PlatformSection';
import AudienceSection from '@/components/landing/AudienceSection';
import AiDoubtSection from '@/components/landing/AiDoubtSection';
import SmartTestsSection from '@/components/landing/SmartTestsSection';
import EvaluationSection from '@/components/landing/EvaluationSection';
import ResourcesSection from '@/components/landing/ResourcesSection';
import RewardsSection from '@/components/landing/RewardsSection';
import PricingSection from '@/components/landing/PricingSection';
import WaitlistSection from '@/components/landing/WaitlistSection';
import Footer from '@/components/landing/Footer';
import type { Plan } from '@/lib/plans';

function App() {
  const [showLanding, setShowLanding] = useState(false);
  const [plan, setPlan] = useState<Plan>('free');
  const choosePlan = (next: Plan) => {
    setPlan(next);
    document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' });
  };

  if (!showLanding) return <Login onSignUp={() => setShowLanding(true)} />;

  return (
    <div className="min-h-screen bg-ink-50">
      <Navbar />
      <main>
        <Hero /><ProblemSection /><PlatformSection /><AudienceSection /><AiDoubtSection />
        <SmartTestsSection /><EvaluationSection /><ResourcesSection /><RewardsSection />
        <PricingSection onChoosePlan={choosePlan} /><WaitlistSection plan={plan} onPlanChange={setPlan} />
      </main>
      <Footer />
    </div>
  );
}
export default App;
